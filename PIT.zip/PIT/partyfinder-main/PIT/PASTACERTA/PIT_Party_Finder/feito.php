<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Você está logado</title>
    <link rel="stylesheet" href="PF.css">
    <link rel="stylesheet" href="teste.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
 
    <h1 id="loginfeito">Login feito com Sucesso </h1>

   <div  id="logout"><a href="logout.php"><button> Logout </button></a></div> 

   <div id="deletar"><a href="deletarusu.php"><button> deletar usuario </button></a></div> 
   <div id="deletar"><a href="./CHAT-PHP-master/src/index.php"><button> Entrar no chat </button></a></div> 
    <div id="DivLoginTotal">
            <div id="LinhaPretaAmarela">
                <div id="DecorçãoPreta"></div>
                <div id="Decorçãoamarela"></div>
                <div id="DecorçãoFundo"></div> 
                <div id="DecorçãoLaranja"></div>
            </div>


    
            <div id="DivCentro">
    
                <div id="DivGridEsquda"> 
                    <div id="LinhaLaranjaEsquerda"></div>
                    <div id="LinhaLaranjaEsquerda"></div>
                    <div id="LinhaAmarelaEsquerda"></div>
                    <div id="LinhaAmarelaEsquerda"></div>
                    <div id="LinhaAmarelaEsquerda"></div>
                    <div id="LinhaCinzaEsquerda"></div>
                    <div id="LinhaAmarelaEsquerda"></div>
                    <div id="LinhaCinzaEsquerda"></div>
                    <div id="LinhaAmarelaEsquerda"></div>
                    <div id="LinhaCinzaEsquerda"></div>
                    <div id="LinhaCinzaEsquerda"></div>
                </div>
                
                <div id="DivLogin">
                    <div id="DivLoginAjuste">

                        
                

                    </div>
                    <div id="DivFormsLogin">

                    </div>


                </div>
    
                <div id="DivGridDireita"> 
                    <div id="LinhaCinzaDireita"></div>
                    <div id="LinhaCinzaDireita"></div>
                    <div id="LinhaCinzaDireita"></div>
                    <div id="LinhaAmarelaDireita"></div>
                    <div id="LinhaAmarelaDireita"></div>
                    <div id="LinhaLaranjaDireita"></div>
                    <div id="LinhaCinzaDireita"></div>
                    <div id="LinhaLaranjaDireita"></div>
                    <div id="LinhaCinzaDireita"></div>
                    <div id="LinhaLaranjaDireita"></div>
                </div>
    
            </div>
    
    
            </div>
    
        </div>
        
</body>
</html>




</body>
</html>
