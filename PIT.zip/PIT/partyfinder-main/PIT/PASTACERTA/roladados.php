<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <?php
        define("INFERIOR",1);
        define("SUPERIOR",4);
        $numero = rand(INFERIOR, SUPERIOR);
        echo $numero."<br>"; 


    ?>
</head>
<body>
    <h3>1d4</h1>
    <h3>1d6</h1>

    <h3>1d8</h1>
    <h3>1d10</h1>
    <h3>1d12</h1>
    <h3>1d20</h1>



</body>
</html>
