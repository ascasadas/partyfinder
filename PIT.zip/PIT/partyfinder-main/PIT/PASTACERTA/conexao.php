<?php
$host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'cadastro';
    $connect = new mysqli($host, $user, $pass, $dbname);
    ?>